#!/usr/bin/python

#https://www.automotivebulbfinder.com/philips/

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
import sys
import unittest
import os
import getpass
import time
import pyautogui
import pandas as pd
import codecs

#function to pass key/keystrokes
def presskey(keyname,num,delay):
    for n in range(0,num):
        pyautogui.press(keyname)
        time.sleep(delay)		
		
#function to fill form		
def fill_form(year):
    for n in year:
        presskey(n,1,1)    
    presskey('tab',1,1)

driver = webdriver.Chrome(executable_path=os.path.join(os.getcwd(),'drivers\\chromedriver.exe'))   
driver.get("https://www.automotivebulbfinder.com/philips/")

time.sleep(5)

def myargs(*args):
    #empty list
    l = []	
    #reading parameters passed to *args
    for param in args:	
        l.append(param)	
        #passing each parameter to fill form function		
        fill_form(param) 	
    #creating filename using builtin join		
    filename = "_".join(l)
    #creating DataFrame and exporting to excel file	
    df = pd.read_html(driver.page_source)
    df[0].to_excel(filename + ".xlsx",index=False)
    #Saving webpage as html file
    html_file = codecs.open(filename + '.html','w',encoding="utf-8")
    html_file.write(driver.page_source)	
    presskey('f5',1,1)	

#calling function for different scenarios / cases
myargs('2015','honda','accord','hybrid','sedan')
myargs('2017','honda','accord','hybrid')
myargs('2016','honda','accord','sport')
myargs('2018','honda','accord')

#close the browser
driver.close()
	
