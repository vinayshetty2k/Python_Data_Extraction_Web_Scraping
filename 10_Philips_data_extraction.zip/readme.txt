# This example is combination of :

Selenium + pyautogui + pandas + *args to download Philips web tables based on certain conditions.